# Flask-Simple-Quiz-App
A very simple Python Flask based Quiz App created under 2 hour for my friend Premshankar using Flask and bootstrap
